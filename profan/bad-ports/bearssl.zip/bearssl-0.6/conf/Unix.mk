# Configuration for a native build on a generic Unix-like system.

# Build directory.
BUILD = build

# Extension for executable files.
E = .elf

# Extension for object files.
O = .o

# Prefix for library file name.
LP = lib

# Extension for library file name.
L = .a

# Prefix for DLL file name.
DP = lib

# Extension for DLL file name.
D = .so

# Output file names can be overridden directly. By default, they are
# assembled using the prefix/extension macros defined above.
# BEARSSLLIB = libbearssl.a
# BEARSSLDLL = libbearssl.so
# BRSSL = brssl
# TESTCRYPTO = testcrypto
# TESTSPEED = testspeed
# TESTX509 = testx509

# File deletion tool.
RM = rm -f

# Directory creation tool.
MKDIR = mkdir -p

# C compiler and flags.
CC = gcc
CFLAGS = -W -Wall -fPIC -m32 -march=i686 -ffreestanding -fno-exceptions -fno-stack-protector -nostdinc -nostdlib -U__GNUC__ -D__profanOS__ -I /home/pf4/Documents/GitHub/profanOS/include/zlibs
CCOUT = -c -o

# Static library building tool.
AR = ar
ARFLAGS = -rcs
AROUT =

# DLL building tool.
LDDLL = gcc
LDDLLFLAGS = -shared -m32 -nostdlib
LDDLLOUT = -o 

# Static linker.
LD = ld
LDFLAGS = -m elf_i386 -nostdlib -T /home/pf4/Documents/GitHub/profanOS/tools/link_elf.ld -lc -L /home/pf4/Documents/GitHub/profanOS/out/zlibs /home/pf4/Documents/GitHub/profanOS/out/make/entry_elf.o
LDOUT = -o 

# C# compiler; we assume usage of Mono.
MKT0COMP = mk$PmkT0.sh
RUNT0COMP = mono T0Comp.exe

# Set the values to 'no' to disable building of the corresponding element
# by default. Building can still be invoked with an explicit target call
# (e.g. 'make dll' to force build the DLL).
#STATICLIB = no
#DLL = no
#TOOLS = no
#TESTS = no
