make clean
make

cp build/brssl.elf /home/pf4/Documents/GitHub/profanOS/out/zapps/f
cp build/testcrypto.elf /home/pf4/Documents/GitHub/profanOS/out/zapps/f
cp build/testspeed.elf /home/pf4/Documents/GitHub/profanOS/out/zapps/f
cp build/testx509.elf /home/pf4/Documents/GitHub/profanOS/out/zapps/f

cp build/libbearssl.a /home/pf4/Documents/GitHub/profanOS/out/zlibs
cp build/libbearssl.so /home/pf4/Documents/GitHub/profanOS/out/zlibs
